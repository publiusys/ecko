#!/usr/bin/env bash
python dummy_to_stdout_driver.py --poll-frequency 1