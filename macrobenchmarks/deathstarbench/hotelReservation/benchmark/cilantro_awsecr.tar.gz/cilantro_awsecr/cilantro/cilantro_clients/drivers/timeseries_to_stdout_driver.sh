#!/usr/bin/env bash
python timeseries_to_stdout_driver.py --csv-file example_timeseries.csv --roll-over --poll-frequency 1