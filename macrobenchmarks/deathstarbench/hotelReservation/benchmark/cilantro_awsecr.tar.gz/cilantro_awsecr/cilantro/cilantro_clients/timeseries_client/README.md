# Timeseries Client
romilb, 08/26/2021

This was a cript to read a timeseries from CSV and publish to Cilantro. This has been deprecated in favor of Cilantro Client, and the timeseries functionality has been moved to `cilantro_clients/data_sources/timeseries_data_source.py`.
See `cilantro_clients/drivers/timeseries_to_stdout_driver.py` for an example.