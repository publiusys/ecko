kubectl proxy --kubeconfig ./kubeconfig/kc_fin_w1_clus1_1.yaml
