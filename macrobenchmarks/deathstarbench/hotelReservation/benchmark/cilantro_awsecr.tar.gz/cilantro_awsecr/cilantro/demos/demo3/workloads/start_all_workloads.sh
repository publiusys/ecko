kubectl create -f c11.yaml
kubectl create -f c11-client.yaml
kubectl create -f c12.yaml
kubectl create -f c12-client.yaml
kubectl create -f c2.yaml
kubectl create -f c2-client.yaml

