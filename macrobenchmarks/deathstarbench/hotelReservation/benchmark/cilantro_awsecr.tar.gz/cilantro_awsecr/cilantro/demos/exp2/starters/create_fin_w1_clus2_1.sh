#!/usr/bin/env bash
set -e

eksctl create cluster -f ./starters/fin-w1-clus2-1.yaml --kubeconfig ./kubeconfig/kc_fin_w1_clus2_1.yaml
cp kubeconfig/kc_fin_w1_clus2_1.yaml ~/.kube/config

echo Prepulling hotelres images.
kubectl create -f ./starters/prepull_hotelres.yaml --kubeconfig ./kubeconfig/kc_fin_w1_clus2_1.yaml
echo Prepull running now. Should complete soon. Note that this needs to be run only once after the cluster has been created with eksctl.
echo Tainting nodes now
./starters/taint_schednode.sh "--kubeconfig ./kubeconfig/kc_fin_w1_clus2_1.yaml"
