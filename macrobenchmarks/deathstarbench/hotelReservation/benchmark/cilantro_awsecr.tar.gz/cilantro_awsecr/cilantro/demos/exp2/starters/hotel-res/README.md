This is a copy of the code in the cilantro-workloads repo.
