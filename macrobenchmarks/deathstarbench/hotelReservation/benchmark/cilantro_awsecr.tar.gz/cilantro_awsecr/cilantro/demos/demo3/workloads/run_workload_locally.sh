python dummy_workload_driver.py --k8s-app-name root--c1--c11 --grpc-port $(CILANTRO_SERVICE_SERVICE_PORT) --grpc-ip $(CILANTRO_SERVICE_SERVICE_HOST) --grpc-client-id root--c1--c11

