"""
    Script for profiling workloads in demo_async.py
    -- kirthevasank
"""

# pylint: disable=import-error

# Cilantro driver for local execution and debug
import argparse
import asyncio
from datetime import datetime
import logging
# Local
from cilantro.backends.alloc_expiration_event_source import AllocExpirationEventSource
from cilantro.data_loggers.data_logger_bank import DataLoggerBank
from cilantro.data_loggers.simple_data_logger import SimpleDataLogger
from cilantro.data_loggers.simple_event_logger import SimpleEventLogger
from cilantro.profiling.profiling_policy import ProfilingPolicy
from cilantro.scheduler.cilantroscheduler import CilantroScheduler
# From demos
from env_demo_2 import generate_env, DummyEventSource, DummyFrameworkManager


NUM_RESOURCES = 60

ENV_DESCR = 'simple'
LOAD_FILE = None

# ENV_DESCR = 'twitter_1476'
# INT_UPPER_BOUND = 0.03
# LIP_CONST = 2
# LOAD_FILE = 'twitter_1476_data'

ALLOC_GRANULARITY = 1 # we cannot assign fractional resources

# For the data logger -----------------------------------------------------
MAX_INMEM_TABLE_SIZE = -1
MAX_INMEM_TABLE_SIZE = 1000
DATA_LOG_WRITE_TO_DISK_EVERY = 10

# Other parameters
ASYNC_SLEEP_TIME = 0.5
SLEEP_TIME_BETWEEN_DATA_REPOLLS = 1.1
ALLOC_EXPIR_TIME = 5 # Allocate every this many seconds

# For logging and saving results ----------------------------------------------
SCRIPT_TIME_STR = datetime.now().strftime('%m%d%H%M%S')
REPORT_RESULTS_EVERY = 15
DATA_LOG_DIR = 'profiling_data_logs/%s'%(SCRIPT_TIME_STR)


def main():
    """ Main function. """
    # Create args ==================================================================================
    parser = argparse.ArgumentParser(description='Arguments for processing profiled data.')
    parser.add_argument('--workload-type-to-profile', '-wttp', type=str,
                        help='Workload type to profile.')
    args = parser.parse_args()
    workload_type_to_profile = args.workload_type_to_profile
    log_file_name = 'logs/prof_%s_%s_%s.log'%(workload_type_to_profile, ENV_DESCR, SCRIPT_TIME_STR)
    logging.basicConfig(filename=log_file_name, level=logging.INFO)
    logger = logging.getLogger(__name__)

    # Create the environment =======================================================================
    env = generate_env()
    env_jobs = env.get_leaf_node_paths()
    print('Created Env: %s'%(env))

    # Create event loggers and framework managers ==================================================
    event_queue = asyncio.Queue()
    event_logger = SimpleEventLogger()
    app_event_sources_dict = {
        j: DummyEventSource(event_queue, sleep_time=ASYNC_SLEEP_TIME, app_name=j,
                            load_file=LOAD_FILE)
        for j in env_jobs}
    alloc_expiration_event_source = AllocExpirationEventSource(event_queue, ALLOC_EXPIR_TIME)
    event_loop = asyncio.get_event_loop()
    framework_manager = DummyFrameworkManager(event_queue, default_jobs=env_jobs,
                                              app_event_sources=app_event_sources_dict,
                                              cluster_resources=NUM_RESOURCES,
                                              alloc_granularity=ALLOC_GRANULARITY)

    # Create data loggers for each node ===========================================================
    data_logger_bank = DataLoggerBank()
    for leaf_path, leaf in env.leaf_nodes.items():
        data_logger = SimpleDataLogger(
            leaf_path, ['load', 'alloc', 'reward', 'sigma', 'event_start_time', 'event_end_time'],
            index_fld='event_start_time', max_inmem_table_size=MAX_INMEM_TABLE_SIZE,
            workload_type=leaf.get_workload_info('workload_type'),
            disk_dir=DATA_LOG_DIR, write_to_disk_every=DATA_LOG_WRITE_TO_DISK_EVERY)
        data_logger_bank.register(leaf_path, data_logger)

    # Decide which leaf to profile ===============================================================
    leaf_path_to_profile = None
    for leaf_path, leaf in env.leaf_nodes.items():
        if leaf.get_workload_info('workload_type') == workload_type_to_profile:
            leaf_path_to_profile = leaf_path
            break
    logger.info('Profiling workload %s with leaf: %s.', workload_type_to_profile,
                leaf_path_to_profile)

    # Create profiling policy ====================================================================
    profiling_policy = ProfilingPolicy(env=env,
                                       resource_quantity=framework_manager.get_cluster_resources(),
                                       leaf_path_to_profile=leaf_path_to_profile)
    profiling_policy.initialise()

    # Pass learner bank and time series model to the scheduler =====================================
    cilantro = CilantroScheduler(event_queue=event_queue,
                                 framework_manager=framework_manager,
                                 event_logger=event_logger,
                                 env=env,
                                 policy=profiling_policy,
                                 data_logger_bank=data_logger_bank,
                                 learner_bank=None,
                                 performance_recorder_bank=None,
                                 load_forecaster_bank=None)

    # Create event sources =========================================================================
    all_event_sources = [alloc_expiration_event_source] + \
                        [aes for _, aes in app_event_sources_dict.items()]
    for s in all_event_sources:
        event_loop.create_task(s.event_generator())
    try:
        event_loop.run_until_complete(cilantro.scheduler_loop())
    finally:
        event_loop.close()


if __name__ == '__main__':
    main()

