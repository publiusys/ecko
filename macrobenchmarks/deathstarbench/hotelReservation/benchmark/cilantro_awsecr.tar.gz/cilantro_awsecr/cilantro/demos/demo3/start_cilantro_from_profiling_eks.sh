kubectl apply -f auth_default_user.yaml
kubectl apply -f config_cilantro_from_profiling_eks.yaml
./fetch_latest_results.sh
