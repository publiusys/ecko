"""
    ** DEPRECATED **
    ** See demo_async.py and read the README to run the demo in this directory. **

    A Demo for Cilantro in the synchronous setting.
    -- kirthevasank
"""

# pylint: disable=import-error
# pylint: disable=too-many-branches
# pylint: disable=too-many-statements


import time
import numpy as np
# Local imports
from cilantro.core.performance_recorder import PerformanceRecorder, PerformanceRecorderBank
from cilantro.data_loggers.simple_data_logger import SimpleDataLogger
from cilantro.learners.base_learner import BaseLearner
from cilantro.learners.ibtree import IntervalBinaryTree
from cilantro.learners.learner_bank import LearnerBank
from cilantro.policies.prop_fairness import PropFairness
from cilantro.policies.mmflearn import MMFLearn
from cilantro.timeseries.oracle_load_forecaster import OracleLoadForecaster
from cilantro.timeseries.ts_forecaster_bank import TSForecasterBank
from cilantro.timeseries.ts_base_learner import TSBaseLearner
from env_demo import generate_env_from_descr

# POLICY_NAME = 'propfair'
POLICY_NAME = 'mmflearn'
# POLICY_NAME = 'mmf'

ENV_DESCR = 'simple'
INT_UPPER_BOUND = 25
LIP_CONST = 10

# ENV_DESCR = 'twitter_1476'
# INT_UPPER_BOUND = 0.03
# LIP_CONST = 2

USE_TIME_SERIES_PREDICTION = True
# USE_TIME_SERIES_PREDICTION = False

NUM_LEARNING_ROUNDS = 200
REPORT_EVERY = NUM_LEARNING_ROUNDS / 10
MAX_NUM_RESOURCES = 100
NUM_RECENT_ROUNDS = 10
INIT_SLEEP_TIME = 5

# Parameters for the ibtree model
NORM_LIP_CONST = 20


PLOT_UTILS = False
# PLOT_UTILS = True


def _print_results(prefix, results):
    """ Prints results. """
    print('%s: res-loss=%0.4f, fair-viol:(max=%0.4f, mean=%0.4f), avg_util=%0.4f'%(
        prefix, results['avg_resource_loss'], results['avg_max_fairness_viol'],
        results['avg_mean_fairness_viol'], results['avg_util']))


def main():
    """ Main function. """
    # N.B: This simulation relies on the environment class to do some of the load generation
    # and serving which will probably be different in a real implementation.

    # Generate the environment ------------------------------------------------------------------
    env = generate_env_from_descr(descr=ENV_DESCR)
    entitlements = env.get_entitlements()
    print('Created Env: %s'%(env))

    # Create data loggers, learners, time_series forcaseters and performance recorder for each leaf
    # node ----------------------------------------------------------------------------------------
    learner_bank = LearnerBank()
    performance_recorder_bank = PerformanceRecorderBank(resource_quantity=MAX_NUM_RESOURCES,
                                                        alloc_granularity=1)
    load_forecaster_bank = TSForecasterBank()
    for leaf_path, leaf in env.leaf_nodes.items():
        # Create the data logger ------------------------------------------------------------------
        # In practice, we might have to compute sigma from other raw metrics.
        data_logger = SimpleDataLogger(
            leaf_path, ['load', 'alloc', 'reward', 'sigma', 'event_start_time', 'event_end_time'],
            index_fld='event_start_time')
        leaf.set_data_logger(data_logger) # This way of setting the data logger for an
                                          # application is for the demo only. We might want to
                                          # do it differently in the actual system.
        # Create the performance recorder ----------------------------------------------------------
        performance_recorder = PerformanceRecorder(
            app_id=leaf_path, performance_goal=leaf.threshold, unit_demand=leaf.unit_demand,
            entitlement=entitlements[leaf_path], data_logger=data_logger)
        performance_recorder_bank.register(leaf_path, performance_recorder)
        # Create the time series learner -----------------------------------------------------------
        if USE_TIME_SERIES_PREDICTION:
            load_forecaster = TSBaseLearner(app_id=leaf_path, data_logger=data_logger,
                                            model='arima-default',
                                            sleep_time_between_data_repolls=0.5,
                                            field_to_forecast='load')
        else:
            load_forecaster = OracleLoadForecaster(leaf)
        load_forecaster_bank.register(leaf_path, load_forecaster)
        load_forecaster.initialise()
        # Create the model and learner -------------------------------------------------------------
#         lip_const = NORM_LIP_CONST * 1 / INT_UPPER_BOUND
        model = IntervalBinaryTree(leaf_path, int_lb=0, int_ub=INT_UPPER_BOUND,
                                   lip_const=LIP_CONST) # Can customise the learner for each leaf.
        learner = BaseLearner(app_id=leaf_path, data_logger=data_logger, model=model,
                              sleep_time_between_data_repolls=0.5)
        learner_bank.register(leaf_path, learner)
        learner.initialise()

    # Create the policy -------------------------------------------------------------------------
    if POLICY_NAME == 'propfair':
        policy = PropFairness(env=env, resource_quantity=MAX_NUM_RESOURCES,
                              load_forecaster_bank=load_forecaster_bank, alloc_granularity=1)
    elif POLICY_NAME == 'mmflearn':
        policy = MMFLearn(env=env, resource_quantity=MAX_NUM_RESOURCES,
                          load_forecaster_bank=load_forecaster_bank, learner_bank=learner_bank,
                          alloc_granularity=1)
    else:
        raise ValueError('Unknown policy_name %s.'%(POLICY_NAME))
    policy.initialise()

    # Run the policies for some time to collect initial data ---------------------------------------
    # N.B: this is needed primarily for the TS prediction since the estimates seem to be a bit off
    # when we don't have enough data. In the real experiment, we might need to bootstrap things with
    # data from the profiling experiment.
    print('Generating initial data')
    for _, leaf in env.leaf_nodes.items():
        leaf.generate_curr_load() # generate initial load
    allocs = policy.get_resource_allocation()
    for _ in range(20):
        for _, leaf in env.leaf_nodes.items():
            leaf.generate_curr_load() # generate load
        for leaf_path, leaf in env.leaf_nodes.items():
            leaf.serve_curr_load(allocs[leaf_path])
    time.sleep(INIT_SLEEP_TIME)

    # Synchronous allocation and learning round ----------------------------------------------------
    for allocation_round_idx in range(NUM_LEARNING_ROUNDS):
        num_data_collection_rounds_this_allocation_round = np.random.randint(5, 10)
        # Within each round we collect data num_data_collection_rounds_this_allocation_round times
        # to simulate the fact that the policy may not update the allocation each time we receive
        # data.
        allocs = policy.get_resource_allocation()
        for _ in range(num_data_collection_rounds_this_allocation_round):
            for _, leaf in env.leaf_nodes.items():
                leaf.generate_curr_load() # generate load
            for leaf_path, leaf in env.leaf_nodes.items():
                leaf.serve_curr_load(allocs[leaf_path])
        # Compute results -----------------------------------------------------------------------
        if (allocation_round_idx + 1) % REPORT_EVERY == 0:
            results = performance_recorder_bank.compute_recent_results()
            results_prefix = '\n%03d (%s):: '%(allocation_round_idx + 1, POLICY_NAME)
            _print_results(results_prefix, results)
#             recent_results = performance_recorder_bank.compute_recent_results(
#                 num_recent_event_logs=NUM_RECENT_ROUNDS)
#             recent_results_prefix = '   - last-%d:: '%(NUM_RECENT_ROUNDS)
#             _print_results(recent_results_prefix, recent_results)
            print('      - %s.'%(results['leaf_utils_descr']))
        # N.B: note that (unlike before) we are not explicitly calling the policy to update the
        # models. This will be done via the learners.
        if PLOT_UTILS:
            if allocation_round_idx in [20, 100, 500]:
                for leaf_path, learner in learner_bank.enumerate():
                    test_inputs = np.linspace(0, INT_UPPER_BOUND, 200)
                    leaf_node = env.leaf_nodes[leaf_path]
                    plot_data = {'test_inputs': test_inputs,
                                 'entitlement':entitlements[leaf_path] * MAX_NUM_RESOURCES,
                                 'unit_demand':leaf_node.unit_demand,
                                 'performance_goal':leaf_node.threshold,
                                 'title': leaf_path,
                                }
                    learner.plot_estimate(plot_data)
                    print('plotted for %s'%(leaf_path))

    # Stop all training loops before quitting ---------------------------------------------------
    print('Stopping all learners.')
    time.sleep(1)
    for _, learner in learner_bank.enumerate():
        learner.stop_training_loop()
    for _, ts_forecaster in load_forecaster_bank.enumerate():
        ts_forecaster.stop_training_loop()

    # Fetch results and report at the end -------------------------------------------------------
    results = performance_recorder_bank.compute_results()
    print_prefix = '\n Final (%s):: '%(POLICY_NAME)
    _print_results(print_prefix, results)
    print('      - %s.'%(results['leaf_utils_descr']))


if __name__ == '__main__':
    main()

