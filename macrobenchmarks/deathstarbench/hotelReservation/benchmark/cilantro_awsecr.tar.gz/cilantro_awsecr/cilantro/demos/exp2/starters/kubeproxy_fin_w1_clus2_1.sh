kubectl proxy --kubeconfig ./kubeconfig/kc_fin_w1_clus2_1.yaml
