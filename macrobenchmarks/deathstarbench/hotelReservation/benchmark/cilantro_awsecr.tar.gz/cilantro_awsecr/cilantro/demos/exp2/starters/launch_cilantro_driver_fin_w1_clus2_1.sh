#!/usr/bin/env bash
set -e
kubectl apply -f ./starters/hotel-res/auth_default_user.yaml --kubeconfig ./kubeconfig/kc_fin_w1_clus2_1.yaml
kubectl apply -f ./starters/hotel-res/dashboard.yaml --kubeconfig ./kubeconfig/kc_fin_w1_clus2_1.yaml
kubectl apply -f ./starters/hotel-res/cilantro-hr-client.yaml --kubeconfig ./kubeconfig/kc_fin_w1_clus2_1.yaml
kubectl apply -f ./starters/config_cilantro_scheduler_eks.yaml --kubeconfig ./kubeconfig/kc_fin_w1_clus2_1.yaml
sleep 10
./starters/fetch_results_fin_w1_clus2_1.sh

