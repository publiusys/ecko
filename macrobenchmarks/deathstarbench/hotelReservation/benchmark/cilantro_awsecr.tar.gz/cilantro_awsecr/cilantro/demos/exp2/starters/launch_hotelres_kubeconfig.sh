#!/usr/bin/env bash
set -e

# Launches the hotel reservation core microservices (19). Does not launch the client.

CONFIG_PATH=$1
WORKLOAD_K8S_PATH=./starters/hotel-res/hotel-res-core/
kubectl apply -Rf ${WORKLOAD_K8S_PATH} --kubeconfig ${CONFIG_PATH}
