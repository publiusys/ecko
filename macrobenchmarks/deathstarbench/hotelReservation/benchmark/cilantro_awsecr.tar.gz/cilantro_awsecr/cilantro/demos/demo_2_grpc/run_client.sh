#!/usr/bin/env bash
APP_NAME="root--c1--app"
IP="localhost"
PORT=10000

python ../../cilantro_clients/drivers/timeseries_to_grpc_driver.py --csv-file ../../cilantro_clients/drivers/example_timeseries.csv --roll-over --client-id ${APP_NAME} --ip ${IP} --port ${PORT} --poll-frequency 1