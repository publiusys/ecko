# Cilantro GRPC Demo

This demo script uses real grpc clients to get utility updates. This script uses a pre-defined environment, but expects a real client to be running and sending updates over grpc. 

This is just one step short of the real scheduler in that it doesn't use kubernetes to populate the environment dynamically. 

Note that any allocations made by this scheduler are not reflected in the clients,
so testing the learning on this script is not useful.
This script is a good check to see if the grpc plumbing is working.

## Usage
Launch `./run_cilantro.sh` in one terminal to see the scheduler output, and `./run_client.sh` in another terminal to see the utility updates sent by the client.