# Cilantro Microservices Workflow

Exp2 borrows the hotel-reservation benchmark from deathstarbench to demonstrate
the application of cilantro to a microservices environment.

## How to run

1. Create a cluster
   ```
   ./starters/create_fin_w1_clus1_1.sh
   ```
2. Create hotel-reservation microservices (Cilantro won't do this for you automatically like in other experiments!)
   ```
   ./starters/launch_hotelres_fin_w1_clus1_1.sh
   ```
3. Start cilantro and hr-client (which starts shooting queries to the microservices. You can set the qps (load) in `./starters/hotel-res/cilantro-hr-client.yaml` by changing the --wrk-qps arg)
   ```
   ./starters/launch_cilantro_driver_fin_w1_clus1_1.sh
   ```
3-4. Or (for convenience) you can launch the microservices and the driver with the following command.
   ```
    ./starters/start_hotelres_experiment_fin_w1_clus1_1.sh 
   ```
4. Access the dashboard with
   ```
   ./starters/kubeproxy_fin_w1_clus1_1.sh
   # http://localhost:8001/api/v1/namespaces/kubernetes-dashboard/services/https:kubernetes-dashboard:/proxy/#/persistentvolumeclaim?namespace=_all
   ```
5. To delete the cluster at the end of the experiment
   ```
   ./starters/clean_fin_w1_clus1_1.sh
   ```
