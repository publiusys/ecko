"""
    Plots the results from the asynchronous demo.
    -- kirthevasank
"""

import argparse

from cilantro.ancillary.plotting import plot_results

WORK_DIRS = [
    'workdirs/minerva_simple_0913191401',
    'workdirs/mmflearn_simple_0913190856',
    'workdirs/mmflearn_simple_0914150954',
    'workdirs/mmf_simple_0913185239',
    'workdirs/propfair_simple_0913185800',
    'workdirs/propfair_simple_0913190353',
    ]


METHOD_ORDER = ['propfair', 'minerva', 'mmflearn', 'mmf']

METHOD_LEGEND_MARKER_DICT = {
    'propfair': {'colour': 'red', 'linestyle': '--', 'legend': 'Proportional Fairness'},
    'minerva': {'colour': 'green', 'linestyle': '-.', 'legend': 'Minerva'},
    'mmflearn': {'colour': 'blue', 'linestyle': '-', 'legend': 'Cilantro+MMF'},
    'mmf': {'colour': 'black', 'linestyle': '-', 'legend': 'MMF'},
    }


def main():
    """ Main function. """
    # parse args
    parser = argparse.ArgumentParser(description='Arguments for running plotting.')
    parser.add_argument('--plot-from', '-from', type=str, default='logs',
                        help='Should be inrun or logs. Specifies which data to plot.')
    parser.add_argument('--profiled-info-dir', '-pid', type=str, default='',
                        help='Directory which has the profiled data saved.')
    args = parser.parse_args()

    # Plot results ----------------------------------------------------------------
    plot_results(WORK_DIRS, args.plot_from, args.profiled_info_dir,
                 METHOD_ORDER, METHOD_LEGEND_MARKER_DICT)


if __name__ == '__main__':
    main()

