rm -r workdirs/*
