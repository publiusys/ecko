#!/usr/bin/env bash
set -e

eksctl create cluster -f ./starters/fin-w1-clus1-4.yaml --kubeconfig ./kubeconfig/kc_fin_w1_clus1_4.yaml
cp kubeconfig/kc_fin_w1_clus1_4.yaml ~/.kube/config

echo Prepulling hotelres images.
kubectl create -f ./starters/prepull_hotelres.yaml --kubeconfig ./kubeconfig/kc_fin_w1_clus1_4.yaml
echo Prepull running now. Should complete soon. Note that this needs to be run only once after the cluster has been created with eksctl.
echo Tainting nodes now
./starters/taint_schednode.sh "--kubeconfig ./kubeconfig/kc_fin_w1_clus1_4.yaml"
