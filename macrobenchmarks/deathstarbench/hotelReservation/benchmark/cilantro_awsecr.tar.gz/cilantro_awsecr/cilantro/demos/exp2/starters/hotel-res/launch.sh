kubectl apply -Rf .
