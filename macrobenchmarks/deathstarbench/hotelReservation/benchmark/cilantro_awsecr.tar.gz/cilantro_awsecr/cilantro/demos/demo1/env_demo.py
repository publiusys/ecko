"""
    ** DEPRECATED **
    ** See demo_async.py and read the README to run the demo in this directory. **

    Generates an environment for the demo.
    -- kirthevasank
"""

import time
import numpy as np
# Local
from cilantro.core.henv import LinearLeafNode, InternalNode, TreeEnvironment


class DummyPropToAllocLeafNode(LinearLeafNode):
    """ A leaf node whose reward is proporitional to the allocation per load. """

    def __init__(self, name, threshold, sigma=0.1, load_file=None):
        """ Constructor. """
        self._ud_thresh_ratio = 1/3
        unit_demand = self._ud_thresh_ratio * threshold
        self.sigma = sigma
        self._data_logger = None
        self.load_file = load_file
        self._curr_event_start_time = None
        super().__init__(name, threshold, unit_demand)
        if load_file is not None:
            with open(load_file, 'r') as data_read_file:
                lines = data_read_file.read().splitlines()
            self.loads = [float(elem) for elem in lines]
            self.load_idx = 0
            self.len_loads = len(self.loads)
        else:
            self.loads = None

    def _get_payoff_per_unit_load(self, alloc_per_unit_load):
        """ Obtain payoff per unit load. """
        return alloc_per_unit_load / self._ud_thresh_ratio

    def _child_generate_curr_load(self):
        """ Returns a random number for the load. """
        if self.loads is None:
            return 5 +  0.1 * np.random.random()
        else:
            self.load_idx += 1
            return self.loads[(self.load_idx - 1) % self.len_loads]

    def serve_curr_load(self, alloc):
        """ Serve the current load. """
        if self._curr_event_start_time is None:
            self._curr_event_start_time = time.time() - 5
        curr_event_end_time = time.time()
        assert self._data_logger
        payoff = self._get_payoff_per_unit_load(alloc/self._curr_load)
        reward = payoff + self.sigma * np.random.normal()
        event_log = {'payoff': payoff, 'reward': reward, 'sigma': self.sigma, 'alloc': alloc,
                     'load': self._curr_load, 'event_start_time': self._curr_event_start_time,
                     'event_end_time': curr_event_end_time}
        self._data_logger.log_event(event_log)
        self._curr_event_start_time = curr_event_end_time

    def _child_serve_curr_load(self, alloc):
        """ Serve current load. """
        raise ValueError('No need to call this function.')

    def set_data_logger(self, data_logger):
        """ Sets the data logger. """
        # NB: This is for the dummy demo purposes only. Ideally, the leaf nodes in the environment
        # object are not used for serving the load or setting the data loggers.
        self._data_logger = data_logger

    @classmethod
    def get_curr_loads(cls):
        """ Get current loads. """
        raise ValueError('No need to call this method in this demo.')


def generate_env_from_descr(descr):
    """ Generate a synthetic organisational tree. """
    if descr == 'simple':
        return generate_env_simple()
    elif descr == 'twitter_1476':
        return generate_env_twitter_1476()
    else:
        raise ValueError('Unknown descr: %s.'%(descr))


def generate_env_simple(load_file=None):
    """ Generate a synthetic organisational tree. """
    root = InternalNode('root')
    child1 = InternalNode('c1')
    child2 = InternalNode('c2')
    child3 = DummyPropToAllocLeafNode('c3', 10, load_file=load_file)
    root.add_children([child1, child2, child3], [1, 1, 2])
    child11 = DummyPropToAllocLeafNode('c11', 5, load_file=load_file)
    child12 = DummyPropToAllocLeafNode('c12', 42, load_file=load_file)
    child1.add_children([child11, child12], [1, 1])
    child21 = DummyPropToAllocLeafNode('c21', 6, load_file=load_file)
    child22 = DummyPropToAllocLeafNode('c22', 12, load_file=load_file)
    child23 = DummyPropToAllocLeafNode('c23', 27, load_file=load_file)
    child2.add_children([child21, child22, child23], [1, 1, 1])
    env = TreeEnvironment(root, 1)
    return env


def generate_env_twitter_1476(load_file='twitter_1476_data', sigma=0.0001):
    """ Generate a synthetic organisational tree. """
    root = InternalNode('root')
    child1 = InternalNode('c1')
    child2 = InternalNode('c2')
    child3 = DummyPropToAllocLeafNode('c3', 0.03, sigma=sigma, load_file=load_file)
    root.add_children([child1, child2, child3], [1, 1, 2])
    child11 = DummyPropToAllocLeafNode('c11', 0.01, sigma=sigma, load_file=load_file)
    child12 = DummyPropToAllocLeafNode('c12', 0.05, sigma=sigma, load_file=load_file)
    child1.add_children([child11, child12], [1, 1])
    child21 = DummyPropToAllocLeafNode('c21', 0.02, sigma=sigma, load_file=load_file)
    child22 = DummyPropToAllocLeafNode('c22', 0.03, sigma=sigma, load_file=load_file)
    child23 = DummyPropToAllocLeafNode('c23', 0.08, sigma=sigma, load_file=load_file)
    child2.add_children([child21, child22, child23], [1, 1, 1])
    env = TreeEnvironment(root, 1)
    return env

