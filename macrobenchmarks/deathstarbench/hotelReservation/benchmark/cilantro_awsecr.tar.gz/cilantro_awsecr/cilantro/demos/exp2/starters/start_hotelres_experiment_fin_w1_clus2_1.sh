./starters/launch_hotelres_fin_w1_clus2_1.sh
./starters/launch_cilantro_driver_fin_w1_clus2_1.sh
