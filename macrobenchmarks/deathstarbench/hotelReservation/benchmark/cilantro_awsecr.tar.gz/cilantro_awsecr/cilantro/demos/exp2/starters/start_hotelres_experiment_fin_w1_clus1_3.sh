./starters/launch_hotelres_fin_w1_clus1_3.sh
./starters/launch_cilantro_driver_fin_w1_clus1_3.sh
