#!/usr/bin/env bash
set -e

./starters/launch_hotelres_kubeconfig.sh ./kubeconfig/kc_fin_w1_clus1_4.yaml
