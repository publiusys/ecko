"""
    A module for testing adding nodes one at a time to the environment and writing
    the environment to a file.
    -- kirthevasank
"""

# Local
from cilantro.core.henv import LinearLeafNode, InternalNode, TreeEnvironment, load_env_from_file, \
                               are_two_environments_equal


write_file_name_1 = 'env_1.txt'
write_file_name_2 = 'env_2.txt'


def generate_env():
    """ Generate a synthetic organisational tree. """
    root = InternalNode('root')
    child1 = InternalNode('c1')
    child2 = InternalNode('c2')
    child3 = LinearLeafNode('c3', 10)
    root.add_children([child1, child2, child3], [1, 1, 2])
    child11 = LinearLeafNode('c11', 5)
    child12 = LinearLeafNode('c12', 42)
    child1.add_children([child11, child12], [1, 1])
    child21 = LinearLeafNode('c21', 6)
    child22 = LinearLeafNode('c22', 12)
    child23 = LinearLeafNode('c23', 27)
    child2.add_children([child21, child22, child23], [1, 1, 1])
    env = TreeEnvironment(root, 1)
    return env


def main():
    """ Main function. """
    env1 = generate_env()
    print('Writing to %s.'%(write_file_name_1))
    env1.write_to_file(write_file_name_1)
    # Now load from file
    print('Now loading from %s and writing to %s.'%(write_file_name_1, write_file_name_2))
    env2 = load_env_from_file(write_file_name_1)
    env2.write_to_file(write_file_name_2)
    assert are_two_environments_equal(env1, env2)
    print('Both env1 and env2 are equal.')


if __name__ == '__main__':
    main()

