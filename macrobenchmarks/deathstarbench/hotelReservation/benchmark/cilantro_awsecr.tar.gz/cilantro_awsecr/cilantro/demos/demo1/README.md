### A simple demo with a synthetic workload

To run this demo, we first need to profile the workloads and process the profiled data. There are
two types of workloads used in this environment with three applications (with two of them having the
same workload type). The two workload types are `dummy1` and `dummy2`. They can be profiled using
the following commands.
```
$ python profile_workloads -wttp dummy1
$ python profile_workloads -wttp dummy2
```
When you profile a workload type, the script runs indefinitely, so you have to stop it at some
point. Usually, 3 rounds of allocations are enough for each allocation quantity we are profiling.
See the `logs/prof_{timestamp}.log` file which logs the current status of the
profiling script.

After running the profiling scripts, you will see a new directory titled `profiling_data_logs` in
the current directory. We now need to process the profiled data which can be done via the following
command. If you want to visualise the profiled data, this can be done by passing the `--to-plot 1` flag.
```
$ python ../../cilantro/profiling/process_profile_data.py --logs-dir profiling_data_logs
```

Finally, you can run the demo via the following command.
The `logs/{policy_name}_{timestamp}.log` file logs the current status of the workload. The script
runs indefinitely unless interrupted.
```
$ python demo_async.py --profiled-info-dir profiled_results
```
