#!/usr/bin/env bash
python demo_2_grpc.py