"""
    Demo using the async driver.
    -- romilbhardwaj
    -- kirthevasank
"""

# pylint: disable=too-many-locals

# Cilantro driver for local execution and debug
import asyncio
import logging
import time
import numpy as np
# Local
from cilantro.backends.base_event_source import BaseEventSource
from cilantro.backends.base_framework_manager import BaseFrameworkManager
from cilantro.core.henv import LinearLeafNode, InternalNode, TreeEnvironment
from cilantro.types.events import AppAddEvent, EventTypes, UtilityUpdateEvent

logger = logging.getLogger(__name__)


class DummyEventSource(BaseEventSource):
    """ A Dummy Event Source. """

    def __init__(self, output_queue, sleep_time, app_name, load_file=None,
                 sigma_max=0.2):
        """
        Generates events at a fixed frequency
        :param sleep_time: time to sleep
        """
        self.sleep_time = sleep_time
        self.app_name = app_name
        self.ud_thresh_ratio = 1/3
        self.sigma_max = sigma_max
        self._curr_alloc = 1
        self.curr_event_start_time = time.time()
        super().__init__(output_queue)
        if load_file is not None:
            with open(load_file, 'r') as data_read_file:
                lines = data_read_file.read().splitlines()
            self.loads = [float(elem) for elem in lines]
            self.load_idx = 0
            self.len_loads = len(self.loads)
        else:
            self.loads = None

    def set_curr_alloc(self, alloc):
        """ Sets the current alloc. """
        self._curr_alloc = alloc

    def get_curr_alloc(self):
        """ Sets the current alloc. """
        return self._curr_alloc

    async def event_generator(self):
        """
        Long running loop that generates events indefinitely
        :return:
        """
        while True:
            await asyncio.sleep(self.sleep_time)
            if self.loads is None:
                curr_load = 5 +  0.1 * np.random.random()
            else:
                self.load_idx += 1
                curr_load = self.loads[(self.load_idx - 1) % self.len_loads]
            sigma = self.sigma_max * (0.5 + 0.5 * np.random.random())
            alloc = self.get_curr_alloc()
            payoff = (alloc/curr_load) / self.ud_thresh_ratio
            reward = payoff + sigma * np.random.normal()
            curr_event_end_time = time.time()
            event = UtilityUpdateEvent(
                app_path=self.app_name, load=curr_load, reward=reward, alloc=alloc,
                sigma=sigma, event_start_time=self.curr_event_start_time,
                event_end_time=curr_event_end_time)
            self.curr_event_start_time = curr_event_end_time
            await self.output_queue.put(event)


class DummyFrameworkManager(BaseFrameworkManager):
    """ Dummy framework manager. """

    def __init__(self,
                 event_queue: asyncio.Queue,
                 default_jobs,
                 app_event_sources,
                 cluster_resources: float = 1,
                 alloc_granularity: float = 1):
        """
        Dummy framework manager for testing without running kubernetes.
        Adds default jobs as AppUpdateEvents at the start to simulate app discovery.
        :param event_queue: Event queue to populate with initial app update events.
        :param cluster_resources: Resource count to return whenever queried
        :param default_jobs: List of jobs to emulate in the start.
        """
        # N.B (@Romil): I am passing a dictionary of app_event_sources since I need to be able to
        # adjust the allocation in the dummy demo. You will probably read this form the k8s state
        # when you are running this for real.
        self.event_queue = event_queue
        self.default_jobs = default_jobs
        self.app_event_sources = app_event_sources
        self.cluster_resources = cluster_resources
        self.alloc_granularity = alloc_granularity
        super().__init__()

        self._generate_init_events()

    def _generate_init_events(self):
        """ Generate initial events. """
        for j in self.default_jobs:
            e = AppAddEvent(app_path=j,
                            app_threshold=1,
                            app_weight=1,
                            timestamp=time.time(),
                            event_type=EventTypes.APP_ADDED)
            self.event_queue.put_nowait(e)

    def apply_allocation(self, allocation):
        """ Apply allocation. """
        for app_path, alloc in allocation.items():
            self.app_event_sources[app_path].set_curr_alloc(alloc)

    def get_cluster_resources(self,
                              resource_label: str = 'cpu'):
        """ Get cluster resources. """
        # pylint: disable=unused-argument
        return self.cluster_resources

    def get_alloc_granularity(self,
                              resource_label: str = 'cpu'):
        """ Get alloc granularity. """
        # pylint: disable=unused-argument
        # N.B (@Romil): I've defined this method in BaseFrameworkManager. alloc_granularity is
        # the minimum quantum we can allocate the resource at. For CPUs, this will be 1.
        return self.alloc_granularity


def generate_env():
    """ Generate a synthetic organisational tree. """
    root = InternalNode('root')
    child1 = InternalNode('c1')
    child2 = LinearLeafNode('c3', threshold=10)
    root.add_children([child1, child2], [1, 1])
    child11 = LinearLeafNode('c11', threshold=5)
    child12 = LinearLeafNode('c12', threshold=42)
    child1.add_children([child11, child12], [1, 1])
    env = TreeEnvironment(root, 1)
    # Add workload information ----------------------------------------------------------
    child2.update_workload_info({'workload_type': 'dummy1', 'a': 1, 'b': 2})
    child11.update_workload_info({'workload_type': 'dummy2', 'a': 3, 'b': 4})
    child12.update_workload_info({'workload_type': 'dummy1', 'c': 5, 'd': 6})
    print('Child 11 workload info: %s'%(child11.workload_info))
    return env

