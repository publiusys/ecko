# ./start_cilantro_driver.sh
# cd workloads
# sleep 2
# ./start_all_workloads.sh
