"""
    Demo using the async driver.
    -- romilbhardwaj
    -- kirthevasank
"""

# pylint: disable=too-many-locals
# pylint: disable=too-many-statements
# pylint: disable=too-many-branches
# pylint: disable=import-error

import argparse
import asyncio
from datetime import datetime
import logging
import os
# Local
from cilantro.ancillary.info_write_load_utils import write_experiment_info_to_files
from cilantro.backends.alloc_expiration_event_source import AllocExpirationEventSource
from cilantro.core.performance_recorder import PerformanceRecorder, PerformanceRecorderBank
from cilantro.data_loggers.data_logger_bank import DataLoggerBank
from cilantro.data_loggers.simple_data_logger import SimpleDataLogger
from cilantro.data_loggers.simple_event_logger import SimpleEventLogger
from cilantro.learners.base_learner import BaseLearner
from cilantro.learners.ibtree import IntervalBinaryTree
from cilantro.learners.timennls import TimeNNLS
from cilantro.learners.learner_bank import LearnerBank
from cilantro.policies.autoscaling import BanditAutoScaler, OracularAutoScaler
from cilantro.policies.as_baselines import K8sAutoScaler, PIDAutoScaler, DS2AutoScaler
from cilantro.policies.ernest import Ernest
from cilantro.policies.prop_fairness import PropFairness
from cilantro.policies.minerva import Minerva
from cilantro.policies.mmflearn import MMFLearn
from cilantro.policies.mmf import HMMFDirect
from cilantro.policies.quasar import Quasar
from cilantro.policies.welfare_policy import UtilWelfareBanditPolicy, UtilWelfareOracularPolicy, \
                                             EgalWelfareBanditPolicy, EgalWelfareOracularPolicy
from cilantro.policies.maximin import EgalWelfareGreedy
from cilantro.policies.evo_alg_welfare import UtilWelfareEvoAlg, EgalWelfareEvoAlg
from cilantro.profiling.profiled_info_loader import ProfiledInfoBank
from cilantro.scheduler.cilantroscheduler import CilantroScheduler
from cilantro.timeseries.ts_forecaster_bank import TSForecasterBank
from cilantro.timeseries.ts_base_learner import TSBaseLearner
# From demo
from env_demo_2 import generate_env, DummyEventSource, DummyFrameworkManager


# POLICY_NAME = 'dummypolicy'
# POLICY_NAME = 'propfair'
# POLICY_NAME = 'minerva'
# POLICY_NAME = 'ernest'
# POLICY_NAME = 'quasar'
POLICY_NAME = 'mmflearn'
# POLICY_NAME = 'mmf'
# POLICY_NAME = 'utilwelflearn'
# POLICY_NAME = 'utilwelforacle'
# POLICY_NAME = 'egalwelflearn'
# POLICY_NAME = 'egalwelforacle'
# POLICY_NAME = 'evoegal'
# POLICY_NAME = 'evoutil'
# POLICY_NAME = 'greedyegal'
# Autoscaling ---------------------------------------------------------------
# POLICY_NAME = 'asoracle'
# POLICY_NAME = 'aslearn'
# POLICY_NAME = 'k8sas'
# POLICY_NAME = 'pidas'
# POLICY_NAME = 'ds2'


NUM_RESOURCES = 60
# NUM_RESOURCES = 600

ENV_DESCR = 'simple'
INT_UPPER_BOUND = 25
LOAD_FILE = None

# ENV_DESCR = 'twitter_1476'
# INT_UPPER_BOUND = 0.03
# LOAD_FILE = 'twitter_1476_data'

ALLOC_GRANULARITY = 1 # we cannot assign fractional resources

# For the data logger -----------------------------------------------------
MAX_INMEM_TABLE_SIZE = -1
MAX_INMEM_TABLE_SIZE = 2000
DATA_LOG_WRITE_TO_DISK_EVERY = 30
NUM_ITERS_FOR_EVO_OPT = -1

# Other parameters
ASYNC_SLEEP_TIME = 0.5
# SLEEP_TIME_BETWEEN_DATA_REPOLLS = 1.1
ALLOC_EXPIR_TIME = 5 # Allocate every this many seconds
NUM_PARALLEL_TRAINING_THREADS = 2
SLEEP_TIME_BETWEEN_TRAINING = 5

# For logging and saving results -------------------------------------------
SCRIPT_TIME_STR = datetime.now().strftime('%m%d%H%M%S')
REPORT_RESULTS_EVERY = 15
DATA_LOG_DIR = os.path.join('workdirs', '%s_%s_%s'%(POLICY_NAME, ENV_DESCR, SCRIPT_TIME_STR))
SAVE_FILE_NAME = os.path.join(DATA_LOG_DIR, 'in_run_results.p')


def main():
    """ Main function. """
    # Parse args and other preliminary set up ======================================================
    parser = argparse.ArgumentParser(description='Arguments for running demo_async.py.')
    parser.add_argument('--profiled-info-dir', '-pid', type=str,
                        help='Directory which has the profiled data saved.')
    args = parser.parse_args()
    if not os.path.exists(DATA_LOG_DIR):
        os.makedirs(DATA_LOG_DIR)
#     log_file_name = os.path.join(DATA_LOG_DIR, 'log.log')
#     logging.basicConfig(filename=log_file_name, level=logging.INFO)
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)

    # Create the environment and load profiled information =========================================
    env = generate_env()
    entitlements = env.get_entitlements()
    env_jobs = env.get_leaf_node_paths()
    print('Created Env: %s'%(env))
    logger.info('Created env: \n%s', str(env))
    experiment_info = {}
    profiled_info_bank = ProfiledInfoBank(args.profiled_info_dir)

    # Create event loggers and framework managers ==================================================
    event_queue = asyncio.Queue()
    event_logger = SimpleEventLogger()
    app_event_sources_dict = {
        j: DummyEventSource(event_queue, sleep_time=ASYNC_SLEEP_TIME, app_name=j,
                            load_file=LOAD_FILE)
        for j in env_jobs}
    alloc_expiration_event_source = AllocExpirationEventSource(event_queue, ALLOC_EXPIR_TIME)
    event_loop = asyncio.get_event_loop()
    framework_manager = DummyFrameworkManager(event_queue, default_jobs=env_jobs,
                                              app_event_sources=app_event_sources_dict,
                                              cluster_resources=NUM_RESOURCES,
                                              alloc_granularity=ALLOC_GRANULARITY)
    experiment_info['resource_quantity'] = framework_manager.get_cluster_resources()
    experiment_info['alloc_granularity'] = framework_manager.get_alloc_granularity()

    # Create data loggers, learners, time_series forcaseters and performance recorder for each leaf
    # node ========================================================================================
    data_logger_bank = DataLoggerBank(write_to_disk_dir=DATA_LOG_DIR,
                                      write_to_disk_every=DATA_LOG_WRITE_TO_DISK_EVERY)
    learner_bank = LearnerBank(num_parallel_training_threads=NUM_PARALLEL_TRAINING_THREADS,
                               sleep_time_between_trains=SLEEP_TIME_BETWEEN_TRAINING)
    load_forecaster_bank = TSForecasterBank(
        num_parallel_training_threads=NUM_PARALLEL_TRAINING_THREADS,
        sleep_time_between_trains=SLEEP_TIME_BETWEEN_TRAINING)
    reward_forecaster_bank = TSForecasterBank(
        num_parallel_training_threads=NUM_PARALLEL_TRAINING_THREADS,
        sleep_time_between_trains=SLEEP_TIME_BETWEEN_TRAINING)
    performance_recorder_bank = PerformanceRecorderBank(
        resource_quantity=framework_manager.get_cluster_resources(),
        alloc_granularity=framework_manager.get_alloc_granularity(),
        report_results_every=REPORT_RESULTS_EVERY, save_file_name=SAVE_FILE_NAME,
        report_results_descr=POLICY_NAME)
    for leaf_path, leaf in env.leaf_nodes.items():
        # Create the data logger ------------------------------------------------------------
        # In practice, we might have to compute sigma from other raw metrics.
        data_logger = SimpleDataLogger(
            leaf_path, ['load', 'alloc', 'reward', 'sigma', 'event_start_time', 'event_end_time'],
            index_fld='event_start_time', max_inmem_table_size=MAX_INMEM_TABLE_SIZE,
            workload_type=leaf.get_workload_info('workload_type'))
        data_logger_bank.register(leaf_path, data_logger)
        # Create the performance recorder ---------------------------------------------------
        leaf_unit_demand = profiled_info_bank.get_unit_demand_for_leaf_node(leaf)
                # N.B: leaf_unit_demand requires oracular information and in our real experiments,
                # will come from profiling information.
        performance_recorder = PerformanceRecorder(
            app_id=leaf_path, performance_goal=leaf.threshold, unit_demand=leaf_unit_demand,
            entitlement=entitlements[leaf_path], data_logger=data_logger)
        performance_recorder_bank.register(leaf_path, performance_recorder)
        # Create the time series learner ----------------------------------------------------
        if POLICY_NAME not in ['propfair']:
            load_forecaster = TSBaseLearner(
                app_id=leaf_path, data_logger=data_logger, model='arima-default',
                field_to_forecast='load')
            load_forecaster_bank.register(leaf_path, load_forecaster)
            load_forecaster.initialise()
        # Create the model and learner ------------------------------------------------------
        if POLICY_NAME in ['mmflearn', 'utilwelflearn', 'egalwelflearn', 'aslearn']:
            lip_const = profiled_info_bank.get_info_for_leaf_node(leaf, 'lip_const')
            int_ub = profiled_info_bank.get_info_for_leaf_node(leaf, 'int_ub')
            model = IntervalBinaryTree(leaf_path, int_lb=0, int_ub=int_ub,
                                       lip_const=lip_const) # Can customise for each leaf.
            learner = BaseLearner(
                app_id=leaf_path, data_logger=data_logger, model=model)
            learner_bank.register(leaf_path, learner)
            learner.initialise()
        elif POLICY_NAME == 'ernest':
            int_ub = profiled_info_bank.get_info_for_leaf_node(leaf, 'int_ub')
            model = TimeNNLS(leaf_path, int_lb=0, int_ub=int_ub)
            learner = BaseLearner(app_id=leaf_path, data_logger=data_logger, model=model)
            learner_bank.register(leaf_path, learner)
            learner.initialise()
        elif POLICY_NAME == 'minerva':
            reward_forecaster = TSBaseLearner(
                app_id=leaf_path, data_logger=data_logger, model='arima-default',
                field_to_forecast='reward')
            reward_forecaster_bank.register(leaf_path, reward_forecaster)
            reward_forecaster.initialise()
        elif POLICY_NAME in ['mmf']: # Oracle policies
            leaf.set_unit_demand(leaf_unit_demand)

    # Create policy ================================================================================
    if POLICY_NAME in ['propfair', 'dummypolicy']:
        policy = PropFairness(env=env, resource_quantity=framework_manager.get_cluster_resources(),
                              load_forecaster_bank=load_forecaster_bank, alloc_granularity=1)
    elif POLICY_NAME == 'minerva':
        policy = Minerva(env=env, resource_quantity=framework_manager.get_cluster_resources(),
                         load_forecaster_bank=load_forecaster_bank,
                         reward_forecaster_bank=reward_forecaster_bank, alloc_granularity=1)
    elif POLICY_NAME == 'mmflearn':
        policy = MMFLearn(env=env, resource_quantity=framework_manager.get_cluster_resources(),
                          load_forecaster_bank=load_forecaster_bank, learner_bank=learner_bank,
                          alloc_granularity=1)
    elif POLICY_NAME == 'mmf':
        policy = HMMFDirect(env=env, resource_quantity=framework_manager.get_cluster_resources(),
                            load_forecaster_bank=load_forecaster_bank, alloc_granularity=1)
    elif POLICY_NAME == 'utilwelforacle':
        policy = UtilWelfareOracularPolicy(
            env=env, resource_quantity=framework_manager.get_cluster_resources(),
            load_forecaster_bank=load_forecaster_bank, profiled_info_bank=profiled_info_bank,
            alloc_granularity=1, num_iters_for_evo_opt=NUM_ITERS_FOR_EVO_OPT)
    elif POLICY_NAME == 'utilwelflearn':
        policy = UtilWelfareBanditPolicy(
            env=env, resource_quantity=framework_manager.get_cluster_resources(),
            load_forecaster_bank=load_forecaster_bank, learner_bank=learner_bank,
            alloc_granularity=1, num_iters_for_evo_opt=NUM_ITERS_FOR_EVO_OPT)
    elif POLICY_NAME == 'evoutil':
        policy = UtilWelfareEvoAlg(env, resource_quantity=framework_manager.get_cluster_resources(),
                                   performance_recorder_bank=performance_recorder_bank,
                                   load_forecaster_bank=load_forecaster_bank,
                                   alloc_granularity=1)
    elif POLICY_NAME == 'egalwelforacle':
        policy = EgalWelfareOracularPolicy(
            env=env, resource_quantity=framework_manager.get_cluster_resources(),
            load_forecaster_bank=load_forecaster_bank, profiled_info_bank=profiled_info_bank,
            alloc_granularity=1, num_iters_for_evo_opt=NUM_ITERS_FOR_EVO_OPT)
    elif POLICY_NAME == 'egalwelflearn':
        policy = EgalWelfareBanditPolicy(
            env=env, resource_quantity=framework_manager.get_cluster_resources(),
            load_forecaster_bank=load_forecaster_bank, learner_bank=learner_bank,
            alloc_granularity=1, num_iters_for_evo_opt=NUM_ITERS_FOR_EVO_OPT)
    elif POLICY_NAME == 'evoegal':
        policy = EgalWelfareEvoAlg(env, resource_quantity=framework_manager.get_cluster_resources(),
                                   performance_recorder_bank=performance_recorder_bank,
                                   load_forecaster_bank=load_forecaster_bank,
                                   alloc_granularity=1)
    elif POLICY_NAME == 'greedyegal':
        policy = EgalWelfareGreedy(env, resource_quantity=framework_manager.get_cluster_resources(),
                                   performance_recorder_bank=performance_recorder_bank,
                                   load_forecaster_bank=load_forecaster_bank,
                                   alloc_granularity=1)
    elif POLICY_NAME == 'ernest':
        policy = Ernest(env, resource_quantity=framework_manager.get_cluster_resources(),
                        load_forecaster_bank=load_forecaster_bank,
                        learner_bank=learner_bank, alloc_granularity=1)
    elif POLICY_NAME == 'quasar':
        policy = Quasar(env, resource_quantity=framework_manager.get_cluster_resources(),
                        performance_recorder_bank=performance_recorder_bank,
                        load_forecaster_bank=load_forecaster_bank,
                        alloc_granularity=1)
    # Autoscaling policies -------------------------------------------------------------------------
    elif POLICY_NAME == 'asoracle':
        policy = OracularAutoScaler(
            env=env, resource_quantity=framework_manager.get_cluster_resources(),
            load_forecaster_bank=load_forecaster_bank,
            profiled_info_bank=profiled_info_bank)
    elif POLICY_NAME == 'aslearn':
        policy = BanditAutoScaler(
            env=env, resource_quantity=framework_manager.get_cluster_resources(),
            load_forecaster_bank=load_forecaster_bank,
            learner_bank=learner_bank)
    elif POLICY_NAME == 'k8sas':
        policy = K8sAutoScaler(
            env=env, resource_quantity=framework_manager.get_cluster_resources(),
            performance_recorder_bank=performance_recorder_bank)
    elif POLICY_NAME == 'pidas':
        policy = PIDAutoScaler(
            env=env, resource_quantity=framework_manager.get_cluster_resources(),
            performance_recorder_bank=performance_recorder_bank)
    elif POLICY_NAME == 'ds2':
        policy = DS2AutoScaler(
            env=env, resource_quantity=framework_manager.get_cluster_resources(),
            load_forecaster_bank=load_forecaster_bank,
            performance_recorder_bank=performance_recorder_bank)
    else:
        raise ValueError('Unknown policy_name %s.'%(POLICY_NAME))
    policy.initialise()


    # Pass learner bank and time series model to the scheduler =====================================
    cilantro = CilantroScheduler(event_queue=event_queue,
                                 framework_manager=framework_manager,
                                 event_logger=event_logger,
                                 env=env,
                                 policy=policy,
                                 data_logger_bank=data_logger_bank,
                                 learner_bank=learner_bank,
                                 performance_recorder_bank=performance_recorder_bank,
                                 load_forecaster_bank=load_forecaster_bank)
    # Initiate reporting of results -----------------------------------------
    performance_recorder_bank.initiate_report_results_loop()
    data_logger_bank.initiate_write_to_disk_loop()
    learner_bank.initiate_training_loop()
    load_forecaster_bank.initiate_training_loop()
    reward_forecaster_bank.initiate_training_loop()

    # Write experimental information to file before commencing experiments =========================
    write_experiment_info_to_files(DATA_LOG_DIR, env, experiment_info)

    # Create event sources =========================================================================
    all_event_sources = [alloc_expiration_event_source] + \
                        [aes for _, aes in app_event_sources_dict.items()]
    for s in all_event_sources:
        event_loop.create_task(s.event_generator())
    try:
        event_loop.run_until_complete(cilantro.scheduler_loop())
    finally:
        event_loop.close()


if __name__ == '__main__':
    main()

