kubectl delete -Rf .
